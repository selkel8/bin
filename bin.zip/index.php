<?php  

sleep(3);

header("Location: ./captcha.html");
?>

